<?php

namespace App\Tars\servant\PHPTest\LaravelTars\tarsObj;

interface TestTafServiceServant {
	/**
	 * @return int
	 */
	public function test();
}

